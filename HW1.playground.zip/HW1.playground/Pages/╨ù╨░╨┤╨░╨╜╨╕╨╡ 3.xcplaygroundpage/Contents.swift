import Foundation

/*:
 ### Задание 3
 
 Необходимо вычислить площадь и периметр прямоугольного треугольника.
 
 >Условия:
 Катеты прямоугольного треугольника:
 AC = 8.0, CB = 6.0. Гипотенузу треугольника AB вычисляем при помощи функции `sqrt(Double)`, заменив `Double` суммой квадратов катетов
 
 */
var sideAC = 8.0
var sideCB = 6.0
var hypotenuse = sqrt(sideAC * sideAC + sideCB * sideCB)

var perimeter = sideAC + sideCB + hypotenuse
var square = (sideAC * sideCB) / 2.0

print(perimeter)
print(square)
//: [Ранее: Задание 2](@previous) | Задание 3 из 3
