// VasilievAG_HW1.1 a.sokolan@swiftbook.ru

import UIKit

/*:
 ## Home Work 1
 
 ### Задание 1
 
 Объявите две строковые константы `firstString` и `secondString`. Присвойте им значения "I can" и "code" (именно такие, ни каких хитростей с лишними пробелами). Выведите в консоль фразу "I can code!" используя эти строковые переменные.
 */
let firstString = "I can"
let secondStrng = "code"
print(firstString + " " + secondStrng + "!")
//: Задание 1 из 3  |  [Далее: Задание 2](@next)
